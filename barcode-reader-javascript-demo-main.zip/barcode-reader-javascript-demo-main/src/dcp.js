import { CodeParser } from "dynamsoft-code-parser";

CodeParser.engineResourcePath = "https://cdn.jsdelivr.net/npm/dynamsoft-code-parser@1.1.0/dist/";

// Please contact Dynamsoft Support (support@dynamsoft.com) to acquire a trial license for Dynamsoft Code Parser
CodeParser.license = "YOUR-LICENSE-KEY";

CodeParser.loadWasm().catch((err)=>console.log(err));

